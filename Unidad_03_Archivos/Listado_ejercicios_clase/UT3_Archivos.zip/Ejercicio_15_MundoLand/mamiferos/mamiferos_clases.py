


class Mamiferos:
    def __init__(self):
        self.mamiferos = cargar_mamiferos()
