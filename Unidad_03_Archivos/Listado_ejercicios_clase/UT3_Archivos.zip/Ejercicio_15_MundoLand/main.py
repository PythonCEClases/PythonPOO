


mams = Mamiferos()
plas = Plantas()



