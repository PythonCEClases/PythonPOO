# Cargar datos de mamíferos
import json
import os


def cargar_mamiferos():
    pass


def cargar_plantas():
    pass
