


class Plantas:
    def __init__(self):
        self.plantas = cargar_plantas()
